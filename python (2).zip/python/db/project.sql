create database pythondb;

create table pythondb.user(
	user_id int AUTO_INCREMENT,
	user_name varchar(100) NOT NULL,
	mail varchar(50) NOT NULL UNIQUE,
	password varchar(10) NOT NULL,
	PRIMARY KEY (user_id)
);

create table pythondb.post(
	post_id int AUTO_INCREMENT,
	post_msg varchar(1000) NOT NULL,
	post_date varchar(50) NOT NULL,
	post_by int,
	PRIMARY KEY (post_id)
);


create table pythondb.contact(
	cid int AUTO_INCREMENT,
	uname varchar(100) NOT NULL,
	email varchar(100) NOT NULL,
	msg varchar(5000) NOT NULL,
	PRIMARY KEY (cid)
);	